import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PetListComponent } from './components/pet-list/pet-list.component';
import { AdoptionFormComponent } from './components/adoption-form/adoption-form.component';
import { PetDetailsComponent } from './components/pet-details/pet-details.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [{ path: '', component: HomeComponent },
  { path: 'pets', component: PetListComponent },
  { path: 'pet/:id', component: PetDetailsComponent },
  { path: 'adopt/:id', component: AdoptionFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
