import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adoption-form',
  templateUrl: './adoption-form.component.html',
  styleUrls: ['./adoption-form.component.css']
})
export class AdoptionFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

   onSubmit() {
    alert('Thank you! Your pet adoption application has been submitted.');
    // Add logic to send form data to backend or service
  }


}
