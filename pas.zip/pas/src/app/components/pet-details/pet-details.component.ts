import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PetService } from '../../services/pet.service';
import { Pet } from '../../models/pet';

@Component({
  styleUrls: ['./pet-details.component.css'],
  selector: 'app-pet-details',
  templateUrl: './pet-details.component.html',
})
export class PetDetailsComponent implements OnInit {
  pet: Pet | undefined;

  constructor(
    private route: ActivatedRoute,
    private petService: PetService
  ) {}

  ngOnInit(): void {
    const petId = Number(this.route.snapshot.paramMap.get('id'));
    this.petService.getPetById(petId).subscribe((data: Pet | undefined) => {
      this.pet = data;
    });
  }
}