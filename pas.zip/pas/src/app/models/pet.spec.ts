import { Pet } from './pet';

describe('Pet', () => {
  it('should create an instance', () => {
    expect(new Pet()).toBeTruthy();
  });
});
