export interface Pet {
  id: number;
  name: string;
  type: string;
  breed: string;
  age: number;
  imageUrl: string;
  description: string;
}